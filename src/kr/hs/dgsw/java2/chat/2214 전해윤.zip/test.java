package kr.hs.dgsw.java2.chat;

public class test {
    public static void main(String[] args) {
        String msg = "DR0010ABCDEFGHIJ";
        System.out.println(msg.substring(14, 18));
    }
}
